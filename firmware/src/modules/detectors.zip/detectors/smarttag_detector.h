#include <Arduino.h>
/*
    nyanBOX by Nyan Devices
    https://github.com/jbohack/nyanBOX
    Copyright (c) 2026 jbohack

    Licensed under the MIT License
    https://opensource.org/licenses/MIT

    SPDX-License-Identifier: MIT
*/

#ifndef SMARTTAG_DETECTOR_H
#define SMARTTAG_DETECTOR_H





void smarttagDetectorSetup();
void smarttagDetectorLoop();

void runSmarttagDetector();
#endif