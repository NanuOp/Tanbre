#include <Arduino.h>
/*
    nyanBOX by Nyan Devices
    https://github.com/jbohack/nyanBOX
    Copyright (c) 2025 jbohack

    Licensed under the MIT License
    https://opensource.org/licenses/MIT

    SPDX-License-Identifier: MIT
*/

#ifndef FLOCK_DETECTOR_H
#define FLOCK_DETECTOR_H





void flockDetectorSetup();
void flockDetectorLoop();
void cleanupFlockDetector();

void runFlockDetector();
#endif
