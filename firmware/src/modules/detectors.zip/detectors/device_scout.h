/*
    nyanBOX by Nyan Devices
    https://github.com/jbohack/nyanBOX
    Copyright (c) 2025 jbohack

    Licensed under the MIT License
    https://opensource.org/licenses/MIT

    SPDX-License-Identifier: MIT
*/

#ifndef DEVICE_SCOUT_H
#define DEVICE_SCOUT_H


#include <Arduino.h>


void deviceScoutSetup();
void deviceScoutLoop();
void cleanupDeviceScout();

void runDeviceScout();
#endif
