#include <Arduino.h>
/*
    nyanBOX by Nyan Devices
    https://github.com/jbohack/nyanBOX
    Copyright (c) 2025 jbohack

    Licensed under the MIT License
    https://opensource.org/licenses/MIT

    SPDX-License-Identifier: MIT
*/

#ifndef flipper_H
#define flipper_H





void flipperZeroDetectorSetup();
void flipperZeroDetectorLoop();

void runFlipperzeroDetector();
#endif