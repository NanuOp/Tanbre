#include <Arduino.h>
/*
    nyanBOX by Nyan Devices
    https://github.com/jbohack/nyanBOX
    Copyright (c) 2025 jbohack

    Licensed under the MIT License
    https://opensource.org/licenses/MIT

    SPDX-License-Identifier: MIT
*/

#ifndef MESHCORE_DETECTOR_H
#define MESHCORE_DETECTOR_H





void meshcoreDetectorSetup();
void meshcoreDetectorLoop();

void runMeshcoreDetector();
#endif