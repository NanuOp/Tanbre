/*
    nyanBOX by Nyan Devices
    https://github.com/jbohack/nyanBOX
    Copyright (c) 2025 jbohack

    Licensed under the MIT License
    https://opensource.org/licenses/MIT

    SPDX-License-Identifier: MIT
*/

#ifndef CARDSKIMMER_DETECTOR_H
#define CARDSKIMMER_DETECTOR_H

#include <Arduino.h>

// #include "config.h"


void cardskimmerDetectorSetup();
void cardskimmerDetectorLoop();

void runCardskimmerDetector();
#endif