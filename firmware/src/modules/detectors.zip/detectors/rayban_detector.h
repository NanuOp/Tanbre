#include <Arduino.h>
/*
    nyanBOX by Nyan Devices
    https://github.com/jbohack/nyanBOX
    Copyright (c) 2025 jbohack

    Licensed under the MIT License
    https://opensource.org/licenses/MIT

    SPDX-License-Identifier: MIT
*/

#ifndef RAYBAN_DETECTOR_H
#define RAYBAN_DETECTOR_H





void raybanDetectorSetup();
void raybanDetectorLoop();

void runRaybanDetector();
#endif
