#include <Arduino.h>
/*
    nyanBOX by Nyan Devices
    https://github.com/jbohack/nyanBOX
    Copyright (c) 2025 jbohack

    Licensed under the MIT License
    https://opensource.org/licenses/MIT

    SPDX-License-Identifier: MIT
*/

#ifndef MESHTASTIC_DETECTOR_H
#define MESHTASTIC_DETECTOR_H





void meshtasticDetectorSetup();
void meshtasticDetectorLoop();

void runMeshtasticDetector();
#endif