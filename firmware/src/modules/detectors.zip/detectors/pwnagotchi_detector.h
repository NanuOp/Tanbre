#include <Arduino.h>
/*
    nyanBOX by Nyan Devices
    https://github.com/jbohack/nyanBOX
    Copyright (c) 2025 jbohack

    Licensed under the MIT License
    https://opensource.org/licenses/MIT

    SPDX-License-Identifier: MIT
*/

#ifndef PWNAGOTCHI_DETECTOR_H
#define PWNAGOTCHI_DETECTOR_H


#include <ArduinoJson.h>

#include <vector>

void pwnagotchiDetectorSetup();
void pwnagotchiDetectorLoop();

void runPwnagotchiDetector();
#endif