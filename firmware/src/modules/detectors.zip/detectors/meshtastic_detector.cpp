/*
    nyanBOX by Nyan Devices
    https://github.com/jbohack/nyanBOX
    Copyright (c) 2025 jbohack

    Licensed under the MIT License
    https://opensource.org/licenses/MIT

    SPDX-License-Identifier: MIT
*/

#include "meshtastic_detector.h"
#include "nyanbox_compat.h"




#include "esp_bt.h"
#include "esp_gap_ble_api.h"
#include "esp_bt_main.h"
#include <vector>



#define BTN_UP BUTTON_PIN_UP
#define BTN_DOWN BUTTON_PIN_DOWN
#define BTN_RIGHT BUTTON_PIN_RIGHT
#define BTN_BACK BUTTON_PIN_LEFT
#define BTN_CENTER BUTTON_PIN_CENTER

struct MeshtasticDeviceData {
  char name[32];
  char address[18];
  int8_t rssi;
  bool hasName;
  unsigned long lastSeen;
  bool isMeshtastic;
};
static std::vector<MeshtasticDeviceData> meshtasticDevices;

static const int MAX_DEVICES = 100;

static int currentIndex = 0;
static int listStartIndex = 0;
static bool isDetailView = false;
static bool isLocateMode = false;
static char locateTargetAddress[18] = {0};
static unsigned long lastButtonPress = 0;
static const unsigned long debounceTime = 200;

static bool needsRedraw = true;
static int lastDeviceCount = 0;
static unsigned long lastLocateUpdate = 0;
const unsigned long locateUpdateInterval = 1000;
static unsigned long lastCountdownUpdate = 0;
const unsigned long countdownUpdateInterval = 1000;
static bool wasScanning = false;

static bool isScanning = false;
static unsigned long lastScanTime = 0;
const unsigned long scanInterval = 30000;
const unsigned long scanDuration = 8;

static bool bleInitialized = false;
static bool scanCompleted = false;

static esp_ble_scan_params_t ble_scan_params = {
    .scan_type              = BLE_SCAN_TYPE_ACTIVE,
    .own_addr_type          = BLE_ADDR_TYPE_PUBLIC,
    .scan_filter_policy     = BLE_SCAN_FILTER_ALLOW_ALL,
    .scan_interval          = 0x100,
    .scan_window            = 0xA0,
    .scan_duplicate         = BLE_SCAN_DUPLICATE_DISABLE
};

static void bda_to_string(uint8_t *bda, char *str, size_t size) {
    if (bda == NULL || str == NULL || size < 18) {
        return;
    }
    snprintf(str, size, "%02x:%02x:%02x:%02x:%02x:%02x",
             bda[0], bda[1], bda[2], bda[3], bda[4], bda[5]);
}

const uint8_t MESHTASTIC_SERVICE_UUID[16] = {
    0xFD, 0xEA, 0x73, 0xE2, 0xCA, 0x5D, 0xA8, 0x9F,
    0x1F, 0x46, 0xA8, 0x15, 0x18, 0xB2, 0xA1, 0x6B
};

bool hasMeshtasticServiceUUID(uint8_t *adv_data, uint8_t adv_data_len) {
    uint8_t uuid_len = 0;
    uint8_t *uuid_data = esp_ble_resolve_adv_data(adv_data, ESP_BLE_AD_TYPE_128SRV_CMPL, &uuid_len);

    if (uuid_data != NULL && uuid_len >= 16) {
        for (int i = 0; i + 16 <= uuid_len; i += 16) {
            if (memcmp(&uuid_data[i], MESHTASTIC_SERVICE_UUID, 16) == 0) {
                return true;
            }
        }
    }

    uuid_len = 0;
    uuid_data = esp_ble_resolve_adv_data(adv_data, ESP_BLE_AD_TYPE_128SRV_PART, &uuid_len);

    if (uuid_data != NULL && uuid_len >= 16) {
        for (int i = 0; i + 16 <= uuid_len; i += 16) {
            if (memcmp(&uuid_data[i], MESHTASTIC_SERVICE_UUID, 16) == 0) {
                return true;
            }
        }
    }

    return false;
}

static void process_scan_result(esp_ble_gap_cb_param_t *scan_result) {
    uint8_t *bda = scan_result->scan_rst.bda;
    char addrStr[18];
    bda_to_string(bda, addrStr, sizeof(addrStr));

    if (strlen(addrStr) < 12) return;

    for (size_t i = 0; i < meshtasticDevices.size(); i++) {
        if (strcmp(meshtasticDevices[i].address, addrStr) == 0) {

            meshtasticDevices[i].rssi = scan_result->scan_rst.rssi;
            meshtasticDevices[i].lastSeen = millis();

            uint8_t adv_name_len = 0;
            uint8_t *adv_name = esp_ble_resolve_adv_data(scan_result->scan_rst.ble_adv,
                                                ESP_BLE_AD_TYPE_NAME_CMPL,
                                                &adv_name_len);

            if (adv_name == NULL) {
                adv_name_len = 0;
                adv_name = esp_ble_resolve_adv_data(scan_result->scan_rst.ble_adv,
                                                    ESP_BLE_AD_TYPE_NAME_SHORT,
                                                    &adv_name_len);
            }

            if (adv_name != NULL && adv_name_len > 0 && adv_name_len < 32) {
                memcpy(meshtasticDevices[i].name, adv_name, adv_name_len);
                meshtasticDevices[i].name[adv_name_len] = '\0';
                meshtasticDevices[i].hasName = true;
            }

            if (!isLocateMode) {
                std::sort(meshtasticDevices.begin(), meshtasticDevices.end(),
                          [](const MeshtasticDeviceData &a, const MeshtasticDeviceData &b) {
                            return a.rssi > b.rssi;
                          });
            }
            return;
        }
    }

    bool isMeshtasticDevice = hasMeshtasticServiceUUID(scan_result->scan_rst.ble_adv,
                                                       scan_result->scan_rst.adv_data_len);

    if (!isMeshtasticDevice) {
        return;
    }

    if (isLocateMode && strlen(locateTargetAddress) > 0) {
        if (strcmp(addrStr, locateTargetAddress) != 0) {
            return;
        }
    } else if (meshtasticDevices.size() >= MAX_DEVICES) {
        return;
    }

    MeshtasticDeviceData newDev = {};
    strncpy(newDev.address, addrStr, 17);
    newDev.address[17] = '\0';
    newDev.rssi = scan_result->scan_rst.rssi;
    newDev.lastSeen = millis();
    newDev.isMeshtastic = true;

    strcpy(newDev.name, "Meshtastic");
    newDev.hasName = false;

    uint8_t adv_name_len = 0;
    uint8_t *adv_name = esp_ble_resolve_adv_data(scan_result->scan_rst.ble_adv,
                                        ESP_BLE_AD_TYPE_NAME_CMPL,
                                        &adv_name_len);

    if (adv_name == NULL) {
        adv_name_len = 0;
        adv_name = esp_ble_resolve_adv_data(scan_result->scan_rst.ble_adv,
                                            ESP_BLE_AD_TYPE_NAME_SHORT,
                                            &adv_name_len);
    }

    if (adv_name != NULL && adv_name_len > 0 && adv_name_len < 32) {
        memcpy(newDev.name, adv_name, adv_name_len);
        newDev.name[adv_name_len] = '\0';
        newDev.hasName = true;
    }

    meshtasticDevices.push_back(newDev);

    if (!isLocateMode) {
        std::sort(meshtasticDevices.begin(), meshtasticDevices.end(),
                  [](const MeshtasticDeviceData &a, const MeshtasticDeviceData &b) {
                    return a.rssi > b.rssi;
                  });
    }

    needsRedraw = true;
}

static void esp_gap_cb(esp_gap_ble_cb_event_t event, esp_ble_gap_cb_param_t *param) {
    switch (event) {
    case ESP_GAP_BLE_SCAN_PARAM_SET_COMPLETE_EVT:
        if (param->scan_param_cmpl.status == ESP_BT_STATUS_SUCCESS) {
            isScanning = true;
            esp_ble_gap_start_scanning(scanDuration);
            lastScanTime = millis();
        }
        break;
    case ESP_GAP_BLE_SCAN_START_COMPLETE_EVT:
        if (param->scan_start_cmpl.status != ESP_BT_STATUS_SUCCESS) {
            isScanning = false;
        }
        break;
    case ESP_GAP_BLE_SCAN_RESULT_EVT:
        switch (param->scan_rst.search_evt) {
        case ESP_GAP_SEARCH_INQ_RES_EVT:
            process_scan_result(param);
            break;
        case ESP_GAP_SEARCH_INQ_CMPL_EVT:
            lastScanTime = millis();
            scanCompleted = true;
            needsRedraw = true;
            if (isLocateMode) {
                isScanning = true;
                esp_ble_gap_start_scanning(scanDuration);
            } else {
                isScanning = false;
            }
            break;
        default:
            break;
        }
        break;
    case ESP_GAP_BLE_SCAN_STOP_COMPLETE_EVT:
        isScanning = false;
        scanCompleted = true;
        break;
    default:
        break;
    }
}

void meshtasticDetectorSetup() {
    meshtasticDevices.clear();
    meshtasticDevices.reserve(MAX_DEVICES);
    currentIndex = listStartIndex = 0;
    isDetailView = false;
    isLocateMode = false;
    memset(locateTargetAddress, 0, sizeof(locateTargetAddress));
    lastButtonPress = 0;
    isScanning = true;
    scanCompleted = false;
    needsRedraw = true;
    lastDeviceCount = 0;
    lastLocateUpdate = 0;
    lastCountdownUpdate = 0;
    wasScanning = false;

    u8g2.begin();
    u8g2.setFont(u8g2_font_6x10_tr);
    u8g2.clearBuffer();
    u8g2.drawStr(0, 10, "Scanning for");
    u8g2.drawStr(0, 20, "Meshtastic...");
    char countStr[32];
    snprintf(countStr, sizeof(countStr), "%d/%d devices", 0, MAX_DEVICES);
    u8g2.drawStr(0, 35, countStr);
    u8g2.setFont(u8g2_font_5x8_tr);
    u8g2.drawStr(0, 60, "Press SEL to exit");
    u8g2.sendBuffer();
    displayMirrorSend(u8g2);

    initBLE();

    esp_ble_gap_register_callback(esp_gap_cb);
    esp_ble_gap_set_scan_params(&ble_scan_params);

    bleInitialized = true;

    
    
    
    
    
}

void meshtasticDetectorLoop() {
    if (!bleInitialized) return;

    unsigned long now = millis();

    if (isScanning && !isLocateMode) {
        if (lastDeviceCount != (int)meshtasticDevices.size() || wasScanning != isScanning) {
            lastDeviceCount = (int)meshtasticDevices.size();
            wasScanning = isScanning;

            u8g2.clearBuffer();
            u8g2.setFont(u8g2_font_6x10_tr);
            u8g2.drawStr(0, 10, "Scanning for");
            u8g2.drawStr(0, 20, "Meshtastic...");

            char countStr[32];
            snprintf(countStr, sizeof(countStr), "%d/%d devices", (int)meshtasticDevices.size(), MAX_DEVICES);
            u8g2.drawStr(0, 35, countStr);

            int barWidth = 120;
            int barHeight = 10;
            int barX = (128 - barWidth) / 2;
            int barY = 42;

            u8g2.drawFrame(barX, barY, barWidth, barHeight);

            int fillWidth = (meshtasticDevices.size() * (barWidth - 4)) / MAX_DEVICES;
            if (fillWidth > 0) {
                u8g2.drawBox(barX + 2, barY + 2, fillWidth, barHeight - 4);
            }

            u8g2.setFont(u8g2_font_5x8_tr);
            u8g2.drawStr(0, 62, "Press SEL to exit");

            u8g2.sendBuffer();
            displayMirrorSend(u8g2);
        }
        return;
    }

    if (wasScanning != isScanning) {
        wasScanning = isScanning;
        needsRedraw = true;
    }


    unsigned long effectiveScanInterval = scanInterval;
    uint32_t effectiveScanDuration = scanDuration;

    if (meshtasticDevices.empty() && isContinuousScanEnabled()) {
        effectiveScanInterval = 500;
        effectiveScanDuration = 3;
    }

    if (!isScanning && scanCompleted && now - lastScanTime > effectiveScanInterval &&
        !isDetailView && !isLocateMode) {
        if (meshtasticDevices.size() >= MAX_DEVICES) {
            std::sort(meshtasticDevices.begin(), meshtasticDevices.end(),
                    [](const MeshtasticDeviceData &a, const MeshtasticDeviceData &b) {
                        if (a.lastSeen != b.lastSeen) {
                            return a.lastSeen < b.lastSeen;
                        }
                        return a.rssi < b.rssi;
                    });

            int devicesToRemove = MAX_DEVICES / 4;
            if (devicesToRemove > 0) {
                meshtasticDevices.erase(meshtasticDevices.begin(),
                                        meshtasticDevices.begin() + devicesToRemove);
            }

            currentIndex = listStartIndex = 0;
        }

        scanCompleted = false;
        isScanning = true;
        esp_ble_gap_start_scanning(effectiveScanDuration);
        lastScanTime = now;
        return;
    }

    if (scanCompleted && now - lastButtonPress > debounceTime) {
        if (!isDetailView && !isLocateMode && digitalRead(BTN_UP) == LOW && currentIndex > 0) {
            --currentIndex;
            if (currentIndex < listStartIndex)
                --listStartIndex;
            lastButtonPress = now;
            needsRedraw = true;
        } else if (!isDetailView && !isLocateMode && digitalRead(BTN_DOWN) == LOW &&
                   currentIndex < (int)meshtasticDevices.size() - 1) {
            ++currentIndex;
            if (currentIndex >= listStartIndex + 5)
                ++listStartIndex;
            lastButtonPress = now;
            needsRedraw = true;
        } else if (!isDetailView && !isLocateMode && digitalRead(BTN_RIGHT) == LOW &&
                   !meshtasticDevices.empty()) {
            isDetailView = true;
            if (isScanning) {
                esp_ble_gap_stop_scanning();
                isScanning = false;
            }
            lastButtonPress = now;
            needsRedraw = true;
        } else if (isDetailView && !isLocateMode && digitalRead(BTN_RIGHT) == LOW &&
                   !meshtasticDevices.empty()) {
            isLocateMode = true;
            strncpy(locateTargetAddress, meshtasticDevices[currentIndex].address, sizeof(locateTargetAddress) - 1);
            locateTargetAddress[sizeof(locateTargetAddress) - 1] = '\0';
            if (!isScanning) {
                isScanning = true;
                esp_ble_gap_start_scanning(scanDuration);
            }
            lastButtonPress = now;
            lastLocateUpdate = now;
            needsRedraw = true;
        } else if (isLocateMode && digitalRead(BTN_BACK) == LOW) {
            isLocateMode = false;
            memset(locateTargetAddress, 0, sizeof(locateTargetAddress));
            if (isScanning) {
                esp_ble_gap_stop_scanning();
                isScanning = false;
            }
            lastButtonPress = now;
            needsRedraw = true;
        } else if (isDetailView && !isLocateMode && digitalRead(BTN_BACK) == LOW) {
            isDetailView = false;
            if (isScanning) {
                esp_ble_gap_stop_scanning();
                isScanning = false;
            }
            lastButtonPress = now;
            needsRedraw = true;
        }
    }

    if (meshtasticDevices.empty()) {
        if (currentIndex != 0 || isDetailView || isLocateMode) {
            needsRedraw = true;
        }
        currentIndex = listStartIndex = 0;
        isDetailView = false;
        isLocateMode = false;
        memset(locateTargetAddress, 0, sizeof(locateTargetAddress));
    } else {
        currentIndex = constrain(currentIndex, 0, (int)meshtasticDevices.size() - 1);
        listStartIndex =
            constrain(listStartIndex, 0, max(0, (int)meshtasticDevices.size() - 5));
    }

    if (isDetailView && now - lastLocateUpdate >= locateUpdateInterval) {
        lastLocateUpdate = now;
        needsRedraw = true;
    }

    if (isLocateMode && now - lastLocateUpdate >= locateUpdateInterval) {
        lastLocateUpdate = now;
        needsRedraw = true;
    }

    if (meshtasticDevices.empty() && scanCompleted && !isScanning &&
        now - lastCountdownUpdate >= countdownUpdateInterval) {
        lastCountdownUpdate = now;
        needsRedraw = true;
    }

    if (!needsRedraw) {
        return;
    }

    needsRedraw = false;
    u8g2.clearBuffer();

    if (meshtasticDevices.empty()) {
        if (isContinuousScanEnabled()) {

            u8g2.setFont(u8g2_font_6x10_tr);
            u8g2.drawStr(0, 10, "Scanning for");
            u8g2.drawStr(0, 20, "Meshtastic...");

            char countStr[32];
            snprintf(countStr, sizeof(countStr), "%d/%d devices", 0, MAX_DEVICES);
            u8g2.drawStr(0, 35, countStr);

            int barWidth = 120;
            int barHeight = 10;
            int barX = (128 - barWidth) / 2;
            int barY = 42;
            u8g2.drawFrame(barX, barY, barWidth, barHeight);

            u8g2.setFont(u8g2_font_5x8_tr);
            u8g2.drawStr(0, 62, "Press SEL to exit");
        } else {

            u8g2.setFont(u8g2_font_6x10_tr);
            u8g2.drawStr(0, 10, "No Meshtastic found");
            u8g2.setFont(u8g2_font_5x8_tr);
            char timeStr[32];
            unsigned long timeLeft = (scanInterval - (now - lastScanTime)) / 1000;
            snprintf(timeStr, sizeof(timeStr), "Scanning in %lus", timeLeft);
            u8g2.drawStr(0, 30, timeStr);
            u8g2.drawStr(0, 45, "Press SEL to exit");
        }
    } else if (isLocateMode) {
        auto &dev = meshtasticDevices[currentIndex];
        u8g2.setFont(u8g2_font_5x8_tr);
        char buf[32];

        char maskedName[33];
        maskName(dev.name, maskedName, sizeof(maskedName) - 1);
        snprintf(buf, sizeof(buf), "%.16s", maskedName);
        u8g2.drawStr(0, 8, buf);

        char maskedAddress[18];
        maskMAC(dev.address, maskedAddress);
        snprintf(buf, sizeof(buf), "%s", maskedAddress);
        u8g2.drawStr(0, 16, buf);

        u8g2.setFont(u8g2_font_7x13B_tr);
        snprintf(buf, sizeof(buf), "RSSI: %d dBm", dev.rssi);
        u8g2.drawStr(0, 28, buf);

        u8g2.setFont(u8g2_font_5x8_tr);
        int rssiClamped = constrain(dev.rssi, -100, -40);
        int signalLevel = map(rssiClamped, -100, -40, 0, 5);

        const char* quality;
        if (signalLevel >= 5) quality = "EXCELLENT";
        else if (signalLevel >= 4) quality = "VERY GOOD";
        else if (signalLevel >= 3) quality = "GOOD";
        else if (signalLevel >= 2) quality = "FAIR";
        else if (signalLevel >= 1) quality = "WEAK";
        else quality = "VERY WEAK";

        snprintf(buf, sizeof(buf), "Signal: %s", quality);
        u8g2.drawStr(0, 38, buf);

        int barWidth = 12;
        int barSpacing = 5;
        int totalWidth = (barWidth * 5) + (barSpacing * 4);
        int startX = (128 - totalWidth) / 2;
        int baseY = 54;

        for (int i = 0; i < 5; i++) {
            int barHeight = 8 + (i * 2);
            int x = startX + (i * (barWidth + barSpacing));
            int y = baseY - barHeight;

            if (i < signalLevel) {
                u8g2.drawBox(x, y, barWidth, barHeight);
            } else {
                u8g2.drawFrame(x, y, barWidth, barHeight);
            }
        }

        u8g2.drawStr(0, 62, "L=Back SEL=Exit");
    } else if (isDetailView) {
        u8g2.setFont(u8g2_font_5x8_tr);
        auto &dev = meshtasticDevices[currentIndex];
        u8g2.setFont(u8g2_font_5x8_tr);
        char buf[32];

        char maskedName[33];
        maskName(dev.name, maskedName, sizeof(maskedName) - 1);
        snprintf(buf, sizeof(buf), "Name: %s", maskedName);
        u8g2.drawStr(0, 10, buf);

        char maskedAddress[18];
        maskMAC(dev.address, maskedAddress);
        snprintf(buf, sizeof(buf), "MAC: %s", maskedAddress);
        u8g2.drawStr(0, 20, buf);
        snprintf(buf, sizeof(buf), "RSSI: %d dBm", dev.rssi);
        u8g2.drawStr(0, 30, buf);
        snprintf(buf, sizeof(buf), "Age: %lus", (millis() - dev.lastSeen) / 1000);
        u8g2.drawStr(0, 40, buf);
        u8g2.drawStr(0, 60, "L=Back SEL=Exit R=Locate");
    } else {
        u8g2.setFont(u8g2_font_6x10_tr);
        char header[32];
        snprintf(header, sizeof(header), "Meshtastic: %d/%d",
                 (int)meshtasticDevices.size(), MAX_DEVICES);
        u8g2.drawStr(0, 10, header);

        for (int i = 0; i < 5; ++i) {
            int idx = listStartIndex + i;
            if (idx >= (int)meshtasticDevices.size())
                break;
            auto &d = meshtasticDevices[idx];
            if (idx == currentIndex)
                u8g2.drawStr(0, 20 + i * 10, ">");
            char line[32];
            const char* displayName = d.name[0] ? d.name : "Meshtastic";
            char maskedName[33];
            maskName(displayName, maskedName, sizeof(maskedName) - 1);
            snprintf(line, sizeof(line), "%.8s | RSSI %d",
                     maskedName, d.rssi);
            u8g2.drawStr(10, 20 + i * 10, line);
        }
    }
    u8g2.sendBuffer();
    displayMirrorSend(u8g2);
}
void runMeshtasticDetector() {
    runNyanModule(meshtasticDetectorSetup, meshtasticDetectorLoop, nullptr);
}
